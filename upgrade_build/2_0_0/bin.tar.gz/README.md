Build for Ubuntu 18.04.

To run on other platforms, build from https://github.com/casper-network/casper-node
 cd node
 cargo build --release

git commit hash: 069bdaf5ce8477d2eb827edabdb3c90bacc1e466
